//
//  Weather.swift
//  HakimaAchak_testExtended
//
//  Created by Apprenant 61 on 31/01/2025.
//

import Foundation
struct Weather: Identifiable {
    var id = UUID()
    var city: String
    var time: String
    var condition: String
    var weatherIcon: String
    var temperatureC: Int
    var temperatureF: Int
    var backgroundImage: String
}

let weathers = [
    Weather(city: "Lyon", time: "12:00", condition: "Ensoleillé", weatherIcon: "sun", temperatureC: 25, temperatureF: 77, backgroundImage: "sun"),
    Weather(city: "Paris", time: "12:00", condition: "Nuages prédominants", weatherIcon: "clouds", temperatureC: 10, temperatureF: 50, backgroundImage: "clouds"),
    Weather(city: "Marseille", time: "12:00", condition: "Neige", weatherIcon: "snow", temperatureC: 1, temperatureF: 34, backgroundImage: "snow"),
    Weather(city: "Lille", time: "12:00", condition: "Pluie", weatherIcon: "rain", temperatureC: 17, temperatureF: 63, backgroundImage: "rain"),
    Weather(city: "Toulouse", time: "12:00", condition: "Belles éclaircies", weatherIcon: "beautiful-clearing", temperatureC: 8, temperatureF: 46, backgroundImage: "beautiful-clearing")
]

