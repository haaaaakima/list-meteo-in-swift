//
//  HakimaAchak_testExtendedApp.swift
//  HakimaAchak_testExtended
//
//  Created by Apprenant 61 on 31/01/2025.
//

import SwiftUI

@main
struct AppDeleguate: App {
    var body: some Scene {
        WindowGroup {
            ListWeatherView()
        }
    }
}
