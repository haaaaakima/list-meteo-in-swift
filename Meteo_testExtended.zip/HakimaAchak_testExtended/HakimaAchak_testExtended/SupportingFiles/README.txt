
--> Vue Principale de l'Application

Le fichier principal de l'application se trouve dans ListWeatherView.swift.

C'est ici que l'interface principale est définie, où l'utilisateur peut rechercher des villes, et consulter les informations météo.

---

Fichier: ListWeatherView.swift

Ce fichier contient la vue de la liste des prévisions météo. Il gère l'affichage de la liste des villes avec des conditions météo, et permet de naviguer vers la vue détaillée de chaque ville.
