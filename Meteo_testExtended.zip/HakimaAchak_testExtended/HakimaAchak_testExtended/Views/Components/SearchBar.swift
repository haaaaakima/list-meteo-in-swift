//
//  SearchBar.swift
//  HakimaAchak_testExtended
//
//  Created by Apprenant 61 on 31/01/2025.
//

import Foundation
import SwiftUI

struct SearchBar: View {
    @Binding var text: String
    var placeholder: String
    
    var body: some View {
        TextField(placeholder, text: $text)
            .padding(.vertical, 8)
            .padding(.horizontal, 40)
            .background(Color(.systemGray6))
            .cornerRadius(10)
            .overlay(
                HStack {
                    Image(systemName: "magnifyingglass")
                        .foregroundColor(.gray)
                        .padding(.leading, 10)
                    
                    Spacer()
                }
            )
            .padding(.horizontal)
    }
}
