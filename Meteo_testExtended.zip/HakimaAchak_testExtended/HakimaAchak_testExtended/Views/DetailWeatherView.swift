//
//  File.swift
//  HakimaAchak_testExtended
//
//  Created by Apprenant 61 on 31/01/2025.
//

import Foundation
import SwiftUI

struct DetailWeatherView: View {
    var weather: Weather
    @State private var showFahrenheit = false // État pour basculer entre °C et °F

    var body: some View {
        NavigationStack {
            ZStack {
                // Image de fond --> backgroundImage
                Image(weather.backgroundImage)
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea()

                // Dégradé pour améliorer la lisibilité du texte
                LinearGradient(
                    gradient: Gradient(colors: [Color.black.opacity(0.6), Color.clear]),
                    startPoint: .bottom,
                    endPoint: .top
                )
                .ignoresSafeArea()

                VStack(spacing: 20) {
                    // Icône météo (symbol)
                    Image(systemName: weather.weatherIcon)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 80, height: 80)
                        .foregroundColor(.white)

                    // Ville et conditions météo --> city + condition
                    VStack {
                        Text(weather.city)
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .foregroundColor(.white)

                        Text(weather.condition)
                            .font(.title2)
                            .foregroundColor(.white.opacity(0.9))
                    }

                    // Températures --> température en °C ou °F
                    HStack(spacing: 10) {
                        Text(showFahrenheit ? "\(weather.temperatureF)°F" : "\(weather.temperatureC)°C")
                            .font(.title)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                    }
                    .padding()
                }
                .padding()
            }
            //.navigationTitle("Détails Météo")
            
            // Bouton dans la barre de navigation pour basculer entre Celsius et Fahrenheit
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        withAnimation {
                            showFahrenheit.toggle() // Basculer entre Celsius et Fahrenheit
                        }
                    }) {
                        HStack {
                            // Affiche "°C" ou "°F" selon l'état
                            Text(showFahrenheit ? "°C" : "°F")
                                .font(.headline)
                                .bold()
                                .foregroundColor(.white)

                            // Icône pour rendre le bouton plus interactif
                            Image(systemName: "arrow.right.circle.fill")
                                .foregroundColor(.white)
                                .imageScale(.medium)
                        }
                        .padding(.horizontal, 10)
                        .padding(.vertical, 5)
                        .background(
                            // Fond de bouton avec couleur en fonction de l'état
                            RoundedRectangle(cornerRadius: 15)
                                .fill(showFahrenheit ? Color.orange.opacity(0.9) : Color.blue.opacity(0.9))
                        )
                    }
                }
            }
        }
    }
}

struct DetailWeatherView_Previews: PreviewProvider {
    static var previews: some View {
        DetailWeatherView(weather: Weather(
            city: "Lyon",
            time: "12:00",
            condition: "Ensoleillé",
            weatherIcon: "sun.max.fill",
            temperatureC: 25,
            temperatureF: 77,
            backgroundImage: "sun"
        ))
    }
}
