//
//  ListWeatherView.swift
//  HakimaAchak_testExtended
//
//  Created by Apprenant 61 on 31/01/2025.
//
import Foundation
import SwiftUI

struct ListWeatherView: View {
    @State private var searchText = "" // Variable pour stocker la recherche
    @State private var filteredWeathers: [Weather] // Liste filtrée des résultats météo

    init() {
        _filteredWeathers = State(initialValue: weathers)
    }

    var body: some View {
        NavigationStack {
            VStack {
                // Barre de recherche
                SearchBar(text: $searchText, placeholder: "Rechercher une ville")
                    .onChange(of: searchText) {
                        // Filtrer les données de 'weathers' en fonction du texte de recherche
                        filteredWeathers = weathers.filter {
                            // Vérifie si le nom de la ville ou la condition météo contient le texte de recherche
                            $0.city.lowercased().contains(searchText.lowercased()) ||
                            $0.condition.lowercased().contains(searchText.lowercased())
                        }
                    }

                ScrollView {
                    VStack(spacing: 15) {
                        ForEach(filteredWeathers) { weather in
                            NavigationLink(destination: DetailWeatherView(weather: weather)) {
                                ZStack {
                                    // Image de fond --> conditions météo
                                    Image(weather.backgroundImage)
                                        .resizable()
                                        .aspectRatio(contentMode: .fill)
                                        .frame(height: 150)
                                        .cornerRadius(10)
                                        .overlay(
                                            LinearGradient(
                                                gradient: Gradient(colors: [Color.black.opacity(0.6), Color.clear]),
                                                startPoint: .bottom,
                                                endPoint: .top
                                            )
                                        )

                                    HStack {
                                        VStack(alignment: .leading, spacing: 5) {
                                            Text(weather.city) // Ville
                                                .font(.title2)
                                                .fontWeight(.bold)
                                                .foregroundColor(.white)

                                            Text(weather.time) // Heure
                                                .font(.subheadline)
                                                .foregroundColor(.white.opacity(0.8))

                                            Spacer()

                                            Text(weather.condition) // Description --> conditions météo
                                                .font(.footnote)
                                                .foregroundColor(.white)
                                        }

                                        Spacer()

                                        // Affichage de la température avec °C (par défaut ici)
                                        Text("\(weather.temperatureC)°C")
                                            .font(.title)
                                            .bold()
                                            .foregroundColor(.white)
                                    }
                                    .padding()
                                }
                                .frame(height: 150)
                                .cornerRadius(15)
                                .shadow(radius: 5)
                            }
                        }
                    }
                    .padding()
                }
            }
            .navigationTitle("Météo")
        }
    }
}

struct ListWeatherView_Previews: PreviewProvider {
    static var previews: some View {
        ListWeatherView()
    }
}
